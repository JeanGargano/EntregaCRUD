#------------------------------ CORRER EL ARCHIVO MAIN ---------------------------------
import json
import couchdb 
conn_string = "http://admin:root@localhost:5984"
server = couchdb.Server(conn_string)
db_name = "recommendation_system"


if db_name in server:
    print("Conectado con la BD")
    db = server[db_name]
else: 
    print("---Creando base de datos")
    db = server.create(db_name)




    
# ------------------------------ ESQUELETO DEL PROGRAMA --------------------------------

def menu():
   tipoOperacion = int(input("¿Que tipo de operacion crud desea realizar?"+ "\nCrear Documento: 1 " + "\nConsultar documento: 2 " + 
                     "\nActualizar documento: 3 " + "\nEliminar documento: 4 " + "\n" ))
   if(tipoOperacion == 1):
    crear()
    bucle()

   elif(tipoOperacion == 2):
    leer()
    bucle()
   elif(tipoOperacion == 3):
    actualizar()
    bucle()
   elif(tipoOperacion == 4):
    eliminar()
    bucle()


def bucle():
  while True:
    continuar = input("desea continuar? ")
    if (continuar == "si"):
        menu()
    else:
      print("Gracias por participar")
    break




# ------------------------------- FUNCIONES PARA LISTAR ---------------------------------


def Read(tipo, llave, valor):
    design_doc = f"_design/{tipo}"
    view_name = f"buscar_por_{llave}"
    
    resultados = db.view(f"{tipo}/{view_name}", key=valor)
    return [row.value for row in resultados]


def leer():
    tipoD = int(input("¿De cual coleccion desea listar el documento: ?" + 
                          "\nTutor: 1 " + "\nCurso: 2" + 
                     "\nUsuario: 3 " + "\n"))
    if(tipoD == 1):
        tipo = "tutores"
        llave = input("Ingrese la llave de búsqueda (nombre, carrera, semestre): ").lower()
        valor = input(f"Ingrese el valor para la llave '{llave}': ")
        tutores = Read(tipo, llave, valor)
        print("tutores encontrados:")
        for tutor in tutores:
            print(tutor)
    elif(tipoD == 2):
        tipo = "cursos"
        llave = input("Ingrese la llave de búsqueda (nombre, categoria, modalidad, gratuito, certificado, calificacion_promedio): ")
        valor = input(f"Ingrese el valor para la llave '{llave}': ")
        cursos = Read(tipo, llave, valor)
        print("Cursos encontrados:")
        for curso in cursos:
            print(curso)
    elif(tipoD == 3):
        tipo = "usuarios"
        llave = str(input("Ingrese la llave de búsqueda (nombre, carrera, semestre): ")).lower()
        valor = input(f"Ingrese el valor para la llave '{llave}': ")
        usuarios = Read(tipo, llave, valor)
        print("Usuarios encontrados:")
        for usuario in usuarios:
            print(usuario)





# ------------------------------------ FUNCIONES PARA CREAR -------------------------------------

def Create(collection, data):
     nuevoDoc = db.save(data)
     return nuevoDoc

def crear():

    tipoDocumento = int(input("¿De cual coleccion desea crear el documento: ?" + 
                          "\nTutor: 1 " + "\nCurso: 2" + 
                     "\nUsuario: 3 " + "\n"))

    if(tipoDocumento == 1):
       idTutor = 0
       nombre = input("Ingrese el nombre del tutor: ")
       carrera = input("Ingrese la carrera del tutor: ")
       semestre = int(input("Ingrese el semestre del tutor: "))
       calificacion_promedio = float(input("Ingrese la calificación promedio del tutor: "))
       curso = input("Ingrese el id del curso que dicta: ")
       tutor = {
                'idTutor':idTutor,
                'tipo':'tutor',
                'nombre':nombre,
                'carrera':carrera,
                'semestre':semestre,
                'calificacion_promedio':calificacion_promedio,
                'curso': curso
            }
       nuevo_tutor = Create('tutores', tutor)
       print(f"Tutor creado con ID: {nuevo_tutor}")

    elif(tipoDocumento == 2):
       idCurso = 0
       nombre = input("Ingrese el nombre del curso: ")
       categoria = input("Ingrese la categoría del curso (artes, humanidades, ciencias básicas, tecnologia): ")
       modalidad = input("Ingrese la modalidad del curso (presencial, remoto): ")
       gratuito = input("¿El curso es gratuito? (V/F): ").upper() == 'V'
       precio = float(input("Ingrese el precio del curso (0 si es gratuito): "))
       duracion = int(input("Ingrese la duración del curso (en horas): "))
       certificado = input("¿El curso otorga certificado? (V/F): ").upper() == 'V'
       calificacion_promedio = float(input("Ingrese la calificación promedio del curso (0.0 a 5.0): "))
       curso = {
                'idCurso':idCurso,
                'tipo':'curso',
                'nombre':nombre,
                'categoria':categoria,
                'modalidad':modalidad,
                'gratuito':gratuito,
                'precio':precio,
                'duracion':duracion,
                'certificado':certificado,
                'calificacion_promedio':calificacion_promedio
            }
       nuevo_curso = Create('cursos', curso)
       print(f"Curso creado con ID: {nuevo_curso}")

    elif(tipoDocumento == 3):
       idUsuario = 0
       nombre = input("Ingrese el nombre del usuario: ")
       carrera = input("Ingrese la carrera del usuario: ")
       semestre = int(input("Ingrese el semestre del usuario: "))
       curso = input("Digite el id del curso que toma: ")
       usuario = {
                'idUsuario':idUsuario,
                'tipo':'usuario',
                'nombre':nombre,
                'carrera':carrera,
                'semestre':semestre,
                'curso': curso
            }
       nuevo_usuario = Create('usuarios', usuario)
       print(f"Usuario creado con ID: {nuevo_usuario}")


#  ------------------------------------- FUNCIONES PARA BORRAR -----------------------------------------
       
def Delete(collection, doc_id):
    #db = couchdb.Database(collection)
    try:
        doc = db[doc_id]
        db.delete(doc)
        print(f"Documento con ID {doc_id} eliminado exitosamente.")
    except couchdb.http.ResourceNotFound:
        print(f"Documento con ID {doc_id} no encontrado en la base de datos.")

def eliminar():
   
    tipoDoc = int(input("¿De cual coleccion desea eliminar el documento: ?" + 
                          "\nTutor: 1 " + "\nCurso: 2" + 
                     "\nUsuario: 3 " + "\n"))
    if(tipoDoc == 1):
        doc_id = input("Ingrese el id: " + "\nPuede utilizar el siguiente id: fae0d1065bdd70e29a50a7d2f5041364: ")
        Delete('tutores', doc_id)
    elif(tipoDoc == 2):
        doc_id = input("Ingrese el id del documento: " + "\nPuede utilizar el siguiente id: fae0d1065bdd70e29a50a7d2f501111d: ")
        Delete('cursos', doc_id)
    elif(tipoDoc == 3):
        doc_id = input("Ingrese el id del documento: " + "\nPuede usar el siguiente id: fae0d1065bdd70e29a50a7d2f5040351: ")
        Delete('usuarios', doc_id)
   




# ---------------------------------- FUNCIONES PARA ACTUALIZAR ---------------------------------------
        


def Update(collection, doc_id, data):
    try:
        doc = db[doc_id]
        # Actualizar los campos necesarios del documento
        for key, value in data.items():
            doc[key] = value
        db.save(doc)
        print(f"Documento con ID {doc_id} fue actualizado exitosamente.")
    except couchdb.http.ResourceNotFound:
        print(f"Documento con ID {doc_id} no encontrado en la base de datos.")

def actualizar():
    tipoDoc = int(input("¿De cuál colección desea actualizar el documento?\n" + 
                        "Tutor: 1\nCurso: 2\nUsuario: 3\n"))
    if  tipoDoc == 1:
        doc_id = input("Ingrese el ID del tutor: " + "\nPuede utilizar el siguiente id: fae0d1065bdd70e29a50a7d2f5041364: ")
        carrera = input("Nueva carrera del tutor: ")
        semestre = int(input("Nuevo semestre del tutor: "))
        calificacion_promedio = float(input("Nueva calificación promedio del tutor: "))
        curso = input("Digite el id del nuevo curso que esta dictando: ")
        
        data = {
            'carrera': carrera,
            'semestre': semestre,
            'calificacion_promedio': calificacion_promedio,
            'curso': curso
        }
        Update('tutores', doc_id, data)
        print("Los campos actualizado fueron: " + json.dumps(data))
        
    elif tipoDoc == 2:
         doc_id = input("Ingrese el ID del curso: " + "\nPuede utilizar el siguiente id: fae0d1065bdd70e29a50a7d2f501111d: ")
         modalidad = input("Ingrese la modalidad del curso (presencial, remoto): ")
         gratuito = input("¿El curso es gratuito? (V/F): ").upper() == 'V'
         precio = float(input("Ingrese el precio del curso (0 si es gratuito): "))
         duracion = int(input("Ingrese la duración del curso (en horas): "))
         certificado = input("¿El curso otorga certificado? (V/F): ").upper() == 'V'
         calificacion_promedio = float(input("Ingrese la calificación promedio del curso (0.0 a 5.0): "))

         data = {
                'modalidad':modalidad,
                'gratuito':gratuito,
                'precio':precio,
                'duracion':duracion,
                'certificado':certificado,
                'calificacion_promedio':calificacion_promedio
            }
         Update('cursos', doc_id, data)
         print("Los campos actualizado fueron: " + json.dumps(data))


       
    elif tipoDoc == 3:
         doc_id = input("Ingrese el ID del usuario: " + "\nPuede usar el siguiente id fae0d1065bdd70e29a50a7d2f5040351: " )
         carrera = input("Ingrese una nueva carrera para el usuario: ")
         semestre = int(input("Ingrese un nuevo semestre del usuario: "))
         curso = input("Digite el id del nuevo curso que esta tomando: ")
         data = {
                'carrera':carrera,
                'semestre':semestre,
                'curso': curso
            }
         Update('usuarios', doc_id, data)
         print("Los campos actualizado fueron: " + json.dumps(data))