from Recommendations import *

print ("Programa desarrollado por Maryori Lasso y Jean Alfred Gargano")

menu()
















    



